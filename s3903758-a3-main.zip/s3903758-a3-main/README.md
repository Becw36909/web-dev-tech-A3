# s3903758-a3
 
 Assessment 3
 Submitted by Rebecca Watson
 Student ID s3903758

 Github URL: https://github.com/rmit-wdt-sp2-2023/s3903758-a3

 Description of Project:
 A basic ASP.NET Core MVC Project, using Code First Models & Database Context
 to represent Courses, Students and Enrolments. 

 Includes an ASP.NET Core Web API & Controller + View consuming the Web API. 

 
