﻿using Assesment3.Models;


namespace Assesment3.Data;

public class SeedData
{
    public static void Initialize(IServiceProvider serviceProvider)
    {
        var context = serviceProvider.GetRequiredService<DBContext>();

        // Look for courses.
        if (context.Courses.Any())
            return; // DB has already been seeded.

        context.Courses.AddRange(
            new Course
            {
                CourseID = "COSC2276",
                Title = "Web Development Technologies",
                CreditPoints = 12,
                Career = "Undergraduate",
                Coordinator = "Matthew Bolger"
            },
            new Course
            {
                CourseID = "COSC2277",
                Title = "Introduction to IT",
                CreditPoints = 7,
                Career = "Undergraduate",
                Coordinator = "Anthony Clapp"
            });

        context.Students.AddRange(
            new Student
            {
                StudentID = "s1234567",
                FirstName = "Rebecca",
                LastName = "Watson", 
                Email = "becw36909@gmail.com",
                MobilePhone = "0422574434",
            },
            new Student
            {
                StudentID = "s7654321",
                FirstName = "Fake",
                LastName = "Student",
                Email = "s7654321@rmit.com.au",
            });

        context.SaveChanges();
    }
}
