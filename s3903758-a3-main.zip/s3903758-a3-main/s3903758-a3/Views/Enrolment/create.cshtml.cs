using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Assesment3.Views.Enrollment
{
    public class createModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
