﻿using Assesment3.Data;
using Assesment3.Models.Repository;

namespace Assesment3.Models.DataManager;


public class StudentManager : IDataRepository<Student, int>
{

    private readonly DBContext _dbContext;

    public StudentManager(DBContext dbContext)
    {
        _dbContext = dbContext;
    }

    public IEnumerable<Student> GetAll()
    {
        return _dbContext.Students.OrderBy(student => student.LastName).ToList();

    }

}
