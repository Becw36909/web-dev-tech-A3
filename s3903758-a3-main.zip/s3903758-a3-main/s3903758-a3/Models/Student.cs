﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Assesment3.Models;

public class Student
{

    [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
    [Display(Name = "Student ID")]
    [Required]
    [RegularExpression(@"^s\d{7}$", ErrorMessage = "StudentID must start with 's' and be followed by 7 digits.")]
    [StringLength(8, ErrorMessage = "StudentID must be exactly 8 characters long.")]
    public string StudentID { get; set; }

    [Required]
    [RegularExpression("^[A-Z][a-zA-Z]*$", ErrorMessage = "First Name must start with an uppercase letter and only contain letters.")]
    [StringLength(30, ErrorMessage = "First Name must not be more than 30 characters long.")]
    public string FirstName { get; set; }

    [Required]
    [RegularExpression("^[A-Z][a-zA-Z]*$", ErrorMessage = "Last Name must start with an uppercase letter and only contain letters.")]
    [StringLength(30, ErrorMessage = "Last Name must not be more than 30 characters long.")]
    public string LastName { get; set; }

    [Required, StringLength(320)]
    [EmailAddress(ErrorMessage = "Email must be a valid email address.")]
    public string Email { get; set; }

    [RegularExpression(@"^04\d{8}$", ErrorMessage = "Mobile Phone must start with '04' and be followed by 8 digits.")]
    [StringLength(10, MinimumLength = 10, ErrorMessage = "Mobile Phone must be 10 characters long.")]
    public string MobilePhone { get; set; }

}
