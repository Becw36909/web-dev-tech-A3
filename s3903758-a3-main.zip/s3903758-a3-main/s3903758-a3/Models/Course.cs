﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Assesment3.Models;

public class Course
{
    [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
    [Display(Name = "Course ID")]
    [Required]
    [RegularExpression(@"^COSC\d{4}$", ErrorMessage = "CourseID must start with COSC and be followed by 4 digits.")]
    [StringLength(8, ErrorMessage = "CourseID must be exactly 8 characters long.")]
    public string CourseID { get; set; }

    [Required, StringLength(100)]
    public string Title { get; set; }

    [Required]
    [Range(1, 12, ErrorMessage = "CreditPoints must be in the range of 1 to 12.")]
    public int CreditPoints { get; set; }

    [Required, StringLength(30)]
    [RegularExpression("^(Undergraduate|Postgraduate)$", ErrorMessage = "Career must be either 'Undergraduate' or 'Postgraduate'.")]
    public string Career { get; set; }

    [Required]
    [RegularExpression("^[A-Z][A-Za-z ]*$", ErrorMessage = "Coordinator must start with an uppercase letter and only contain letters and spaces.")]
    [StringLength(50, ErrorMessage = "Coordinator must not exceed 50 characters.")]
    public string Coordinator { get; set;}
}
