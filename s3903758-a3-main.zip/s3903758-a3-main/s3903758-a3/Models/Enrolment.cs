﻿using Microsoft.EntityFrameworkCore;

namespace Assesment3.Models;

// Set composite primary key with PrimaryKey annotation
[PrimaryKey(nameof(CourseID), nameof(StudentID))]
public class Enrolment
{
    public string CourseID { get; set; }
    public virtual Course Course { get; set; }

    public string StudentID { get; set; }
    public virtual Student Student { get; set; }

}
