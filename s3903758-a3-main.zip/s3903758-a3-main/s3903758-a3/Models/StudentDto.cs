﻿namespace Assesment3.Models;

public class StudentDto
{

}
