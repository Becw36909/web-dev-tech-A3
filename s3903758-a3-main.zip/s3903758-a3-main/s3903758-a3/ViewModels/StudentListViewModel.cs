﻿using Assesment3.Models;

namespace Assesment3.ViewModels
{
    public class StudentListViewModel
    {
        public List<Student> Students { get; set; }

    }
}
