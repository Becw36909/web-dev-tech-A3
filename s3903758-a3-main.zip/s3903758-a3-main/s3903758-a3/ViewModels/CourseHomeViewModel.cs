﻿using Assesment3.Models;

namespace Assesment3.ViewModels;

public class CourseHomeViewModel
{
    public Course Course { get; set; }
    public List<Student> EnrolledStudents { get; set; }
}
