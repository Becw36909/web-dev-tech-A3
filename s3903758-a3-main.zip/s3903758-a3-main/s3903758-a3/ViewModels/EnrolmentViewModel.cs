﻿using Assesment3.Models;

namespace Assesment3.ViewModels;

public class EnrolmentViewModel
{
    public List<Course> Courses { get; set; }
    public List<Student> Students { get; set; }
    public string ErrorMessage { get; set; }
    public string StudentID { get; set; }
    public string CourseID { get; set; }
}
