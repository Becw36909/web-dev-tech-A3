﻿using System.Text;
using Assesment3.Models;
using Assesment3.ViewModels; 
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace Assesment3.Controllers;

public class StudentController : Controller
{
    private readonly IHttpClientFactory _clientFactory;
    private HttpClient Client => _clientFactory.CreateClient();


    public StudentController(IHttpClientFactory clientFactory) => _clientFactory = clientFactory;

    // GET: Movies/Index
    public async Task<IActionResult> Index()
    {
        var response = await Client.GetAsync("api/student");

        if (!response.IsSuccessStatusCode)
            throw new Exception();

        // Storing the response details received from web api.
        var result = await response.Content.ReadAsStringAsync();

        // Deserializing the response received from web api and storing into a list.
        var students = JsonConvert.DeserializeObject<List<Student>>(result);

        var viewModel = new StudentListViewModel
        {
            Students = students
        };

        return View(viewModel);
    }

}