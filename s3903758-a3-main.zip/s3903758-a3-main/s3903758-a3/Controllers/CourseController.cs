﻿using Assesment3.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using Assesment3.Models;
using Assesment3.ViewModels;

namespace Assesment3.Controllers;

public class CourseController : Controller
{
    private readonly DBContext _context;

    public CourseController(DBContext context) => _context = context;

    public IActionResult Create()
    {
        return View();
    }

    // POST: Course/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create([Bind("CourseID,Title,CreditPoints,Career,Coordinator")] Course course)
    {

        // ReSharper disable once InvertIf
        if (ModelState.IsValid)
        {
            var existingCourse = _context.Courses.FirstOrDefault(c => c.CourseID == course.CourseID);

            if (existingCourse != null)
            {
                ModelState.AddModelError("", "CourseID already exists. Try Again.");
            }
            else
            {
                // Proceed with creating new course
                _context.Add(course);
                _context.SaveChangesAsync();
                return RedirectToAction("Index", "Home"); // Redirect to the home page
            }
        }
        return View("create");
    }
}
