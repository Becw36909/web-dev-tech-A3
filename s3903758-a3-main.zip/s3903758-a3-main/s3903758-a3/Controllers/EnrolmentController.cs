﻿using Assesment3.Data;
using Assesment3.Models;
using Assesment3.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace Assesment3.Controllers;

public class EnrolmentController : Controller
{
    private readonly DBContext _context;

    public EnrolmentController(DBContext context) => _context = context;

    public IActionResult Create()
    {

        var courses = _context.Courses.OrderBy(course => course.Title).ToList();

        var students = _context.Students.OrderBy(course => course.FirstName).ToList();


        return View("create", new EnrolmentViewModel
        {
            Courses = courses,
            Students = students,
        });
    }

    [HttpPost]
    public IActionResult Enrol(EnrolmentViewModel viewmodel)
    {
        if (ModelState.IsValid)
        {
            var existingEnrollment = _context.Enrolled
                .FirstOrDefault(e => e.StudentID == viewmodel.StudentID && e.CourseID == viewmodel.CourseID);

            if (existingEnrollment != null)
            {
                ModelState.AddModelError("", "Student is already enrolled in this course. Try Again.");
            }
            else
            {
                // Proceed with enrollment
                var newEnrollment = new Enrolment
                {
                    StudentID = viewmodel.StudentID,
                    CourseID = viewmodel.CourseID
                };

                _context.Enrolled.Add(newEnrollment);
                _context.SaveChanges();

                return RedirectToAction("Index", "Home"); // Redirect to the home page
            }
        }

        // If validation fails, show the enrollment form again
        var courses = _context.Courses.OrderBy(course => course.Title).ToList();

        var students = _context.Students.OrderBy(course => course.FirstName).ToList();


        return View("create", new EnrolmentViewModel
        {
            Courses = courses,
            Students = students,
        });
    }


}
