﻿using Assesment3.Data;
using Assesment3.Models;
using Assesment3.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Assesment3.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly DBContext _context;

        public HomeController(ILogger<HomeController> logger, DBContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            var courses = _context.Courses.OrderBy(course => course.Title).ToList();
            var viewModelList = new List<CourseHomeViewModel>();

            foreach (var course in courses)
            {
                var enrolledStudents = _context.Enrolled
                    .Where(enrolment => enrolment.CourseID == course.CourseID)
                    .Select(enrolment => enrolment.Student)
                    .ToList();

                var viewModel = new CourseHomeViewModel
                {
                    Course = course,
                    EnrolledStudents = enrolledStudents
                };

                viewModelList.Add(viewModel);
            }

            return View(viewModelList);
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}