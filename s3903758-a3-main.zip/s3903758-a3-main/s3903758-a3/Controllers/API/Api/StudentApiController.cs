﻿using Assesment3.Models;
using Assesment3.Models.DataManager;
using Microsoft.AspNetCore.Mvc;

namespace Assesment3.Controllers.API.Api
{
    [ApiController]
    [Route("api/student")]
    public class StudentApiController : ControllerBase
    {

        private readonly StudentManager _repo;

        public StudentApiController(StudentManager repo)
        {
            _repo = repo;
        }

        // GET: api/students
        [HttpGet]
        public IEnumerable<Student> Get()
        {
            return _repo.GetAll();
        }

    }
}
